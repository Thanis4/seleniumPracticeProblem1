package pageobjects;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStorePageObject extends PageObject {
	private static final Logger log = Logger.getLogger(MyStorePageObject.class);
	private static MyStorePageObject m_instance;
	@FindBy(linkText = "Sign out")
	WebElement signOutButton;
	@FindBy(id = "search_query_top")
	WebElement searchBox;
	@FindBy(name = "submit_search")
	WebElement searchButton;
	// Search Result Element
	@FindBy(className = "ajax_block_product")
	WebElement searchResult;

	protected MyStorePageObject() {
// no PageTitle
	}

	protected MyStorePageObject(WebDriver _driver) {
// no PageTitle
		PageFactory.initElements(_driver, this);
	}

	public MyStoreSignInPage SignOut() {
		log.debug("Signing Out");
		Selenium.Click(signOutButton);
		SeleniumHelper.Seconds(1.2);
		return MyStoreSignInPage.GetInstance();
	}

	public MyStoreSearchResultsPage SearchForItem(String _itemName) {
		log.debug("Searching for " + _itemName);
		Selenium.Input(searchBox, _itemName);
		Selenium.Click(searchButton);
		return MyStoreSearchResultsPage.GetInstance();
	}

	// Fill in Search field
	public MyStorePageObject FillSearchField() {
		log.debug("fill in search the search field");
		Selenium.Input(searchBox, "t-shirts");
		SeleniumHelper.Seconds(1.2);
		return GetInstance();
	}

	// Click Search button
	public MyStorePageObject SubmitSearch() {
		log.debug("click the submit button");
		Selenium.Click(searchButton);
		SeleniumHelper.Seconds(1.2);
		return GetInstance();
	}

	// Verify at least one search result exists
	public MyStorePageObject ResultsExist() {
		log.debug("display search results");
		SeleniumHelper.VerifyItemExists(searchResult);
		return GetInstance();
	}

	public static MyStorePageObject GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStorePageObject(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}