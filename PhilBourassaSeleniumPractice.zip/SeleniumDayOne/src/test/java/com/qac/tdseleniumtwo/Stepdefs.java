package com.qac.tdseleniumtwo;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.MyStoreContactUsPage;
import pageobjects.MyStoreCreateAnAccountPage;
import pageobjects.MyStoreHomePage;
import pageobjects.MyStoreItemAddedToCartWindow;
import pageobjects.MyStoreItemDescriptionPage;
import pageobjects.MyStoreMyAccountPage;
import pageobjects.MyStorePageObject;
import pageobjects.MyStoreSearchResultsPage;
import pageobjects.MyStoreShoppingCartPage;
import pageobjects.MyStoreSignInPage;
import selenium.SeleniumHelper;

public class Stepdefs {
	MyStoreHomePage homePage = MyStoreHomePage.GetInstance();
	MyStoreSignInPage signInPage = MyStoreSignInPage.GetInstance();
	MyStoreCreateAnAccountPage createAccountPage = MyStoreCreateAnAccountPage.GetInstance();
	MyStoreMyAccountPage myAccountPage = MyStoreMyAccountPage.GetInstance();
	MyStoreContactUsPage contactUsPage = MyStoreContactUsPage.GetInstance();
	// New for Practice Problem STARTS
	MyStoreSearchResultsPage searchResultsPage = MyStoreSearchResultsPage.GetInstance();
	MyStoreItemDescriptionPage itemDescriptionPage = MyStoreItemDescriptionPage.GetInstance();
	MyStoreItemAddedToCartWindow itemAddedToCartWindow = MyStoreItemAddedToCartWindow.GetInstance();
	MyStoreShoppingCartPage shoppingCartPage = MyStoreShoppingCartPage.GetInstance();
	// New for Practice Problem ENDS
	// Add MyStorePageObject
	MyStorePageObject myStorePage = MyStorePageObject.GetInstance();

	@Given("^user is on homepage$")
	public void user_is_on_homepage() throws Exception {
		homePage.NavigateToThisPage();
	}

	@When("^user navigates to signinpage$")
	public void user_navigates_to_signinpage() {
		homePage.NavigateToSignInPage();
	}

	@When("user begins registration")
	public void user_begins_registration() {
		signInPage.CreateAnAccount();
	}

	@When("user enters default data")
	public void user_enters_default_data() {
		createAccountPage.EnterAccountDetails();
	}

	@When("user logs out")
	public void user_logs_out() {
		myAccountPage.SignOut();
	}

	@Then("verify signinpage title")
	public void verify_signinpage_title() {
		signInPage.VerifyTitle();
	}

	@When("user signs in")
	public void user_signs_in() {
		signInPage.SignIn();
	}

	@Then("verify myaccountpage title")
	public void verify_myaccountpage_title() {
		myAccountPage.VerifyTitle();
	}

	@When("user navigates to contactuspage")
	public void user_navigates_to_contactuspage() {
		myAccountPage.NavigateToContactUsPage();
	}

	@Then("verify contactuspage title")
	public void verify_contactuspage_title() {
		contactUsPage.VerifyTitle();
	}

	// T-shirts search STARTS

	@When("user enters the keyword into search field")
	public void user_enters_the_keyword_into_search_field() {
		myStorePage.FillSearchField();
	}

	@When("user clicks the submit button")
	public void user_click_the_submit_button() {
		myStorePage.SubmitSearch();
	}

	@Then("the search page is displayed with results")
	public void the_search_page_is_displayed_with_results() {
		myStorePage.ResultsExist();
	}
	// t-shirt search ENDS

	// New for Practice Problem STARTS
	@When("user searches for {string}")
	public void user_searches_for(String string) {
		myAccountPage.SearchForItem(string);
		searchResultsPage.SelectItem(string);
	}

	@When("user adds item to cart")
	public void user_adds_item_to_cart() {
		itemDescriptionPage.AddItemToCart();
		SeleniumHelper.Seconds(2);
	}

	@When("user continues shopping")
	public void user_continues_shopping() {
		itemAddedToCartWindow.pressContinueShoppingButton();
		SeleniumHelper.Seconds(2);
	}

	@When("user clicks shopping cart")
	public void user_clicks_shopping_cart() {
		itemDescriptionPage.goToShoppingCart();
	}

	@Then("user verifies {string} is in cart")
	public void user_verifies_is_in_cart(String string) {
		shoppingCartPage.VerifyItemPresenceInCart(string);
	}

	@Then("user signs out")
	public void user_signs_out() {
		shoppingCartPage.SignOut();
	}
	// New for Practice Problem ENDS
}