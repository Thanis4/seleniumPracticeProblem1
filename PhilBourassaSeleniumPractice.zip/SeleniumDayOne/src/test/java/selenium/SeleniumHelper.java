package selenium;

import java.util.List;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

/**
 * This is a helper class which contains static methods to deal with Selenium
 * This class is a Singleton. to access it call the static method GetInstance()
 *
 * e.g. SeleniumHelper helper = SeleniumHelper.GetInstance();
 *
 * @author Alex McCann
 *
 */

public class SeleniumHelper {
	private final Logger log = LogManager.getLogger(SeleniumHelper.class);
	private static WebDriver driver = null;
	private final String pathToChromeDriver = "./webdrivers/chromedriver.exe";

	public WebDriver GetDriver() {
		if (driver == null) {
			System.setProperty("webdriver.chrome.driver", pathToChromeDriver);
			driver = new ChromeDriver();
			log.info("Generating ChromeDriver...");
		}
		return driver;
	}

	public void CloseDriver() {
		if (driver != null) {
			log.info("Closing Chrome Driver");
			driver.quit();
		}
	}

	public static WebElement FindElement(By _locator) {
		return driver.findElement(_locator);
	}

	public static List<WebElement> FindElements(By _locator) {
		return driver.findElements(_locator);
	}

	public static String GetTitle() {
		return driver.getTitle();
	}

	public static String GetPageSource() {
		return driver.getPageSource();
	}

	public static void Get(String _url) {
		driver.get(_url);
	}

	public static boolean isMaven() {
		return System.getProperty("java.class.path").contains("pom-framework-");
	}

	public static void ScrollToBottomOfPageWithJS() {
		JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
		javascriptExecutor.executeScript("window.scrollTo(0, document.body.scrollHeight);");
	}

	public static void ScrollToTopOfPageWithJS() {
		JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
		javascriptExecutor.executeScript("window.scrollTo(0, 0);");
	}

	public static void ScrollDownToElement(By locator) {
		WebElement element = FindElement(locator);
		Actions actions = new Actions(driver);
		actions.moveToElement(element);
		actions.perform();
	}

	public static void ScrollDownToElementWithJS(By locator, int increment) {
		int currentY = 0;
		JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
		boolean found = false;
		while (!found) {
			try {
				WebElement element = FindElement(locator);
				found = element.isDisplayed();
			} catch (Exception ex) {
				javascriptExecutor.executeScript("window.scrollTo(" + 0 + ", " + currentY + ");");
				currentY += increment;
			}
		}
	}

	public static void ScrollElementIntoView(WebElement element) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public static void Seconds(int timeOutSeconds) {
		try {
			Thread.sleep(timeOutSeconds * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void Seconds(double timeOutSeconds) {
		try {
			Thread.sleep((int) (timeOutSeconds * 1000));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void MouseHoverByJavaScript(WebElement element)
	{
	String javaScript = "var evObj = document.createEvent('MouseEvents');"
	+ "evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);"
	+ "arguments[0].dispatchEvent(evObj);";
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript(javaScript, element);
	// no way around this one. JavaScript executes asynchronously
	try
	{
	Thread.sleep(500);
	} catch (InterruptedException e)
	{
	e.printStackTrace();
	}
	}

	public static By GetCSSSelectorFromAttribute(String attribute, String value, String tagName) {
		if (tagName.isEmpty()) {
			tagName = "*";
		}
		// "tagName[attributeName='value']"
		String selectorString = tagName + "[" + attribute + "='" + value + "']";
		return By.cssSelector(selectorString);
	}

	public static By GeXPathSelectorFromAttribute(String attribute, String value, String tagName) {
		if (tagName.isEmpty()) {
			tagName = "*";
		}
		// "//element[@attribute='value']"
		String selectorString = "//" + tagName + "[@" + attribute + "='" + value + "']";
		return By.xpath(selectorString);
	}

	public static By GetXpathFromElementContainingText(String text, String tagName) {
		if (tagName.isEmpty()) {
			tagName = "*";
		}
		//// tagName[contains(text(), 'textInElement')]
		String selectorString = "//" + tagName + "[contains(text(), '" + text + "')]";
		return By.xpath(selectorString);
	}

	public static boolean VerifyTextPresentOnPage(String _expectedText) {
		String pageInformation = driver.getPageSource();
		if (pageInformation.contains(_expectedText)) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean VerifyPageTitle(String _expTitle) {
		String pageTitle;
		pageTitle = driver.getTitle();
		if (pageTitle.contains(_expTitle)) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean VerifyItemExists(WebElement _element) {
		if (_element.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}

	// --------------------------------------------------------------------------//
	// Singleton code
	private static SeleniumHelper m_instance = null;

	/**
	 * Private Constructor to prevent calling new() from outside the class.
	 */
	private SeleniumHelper() {
	}

	/**
	 * This function return the instance of the SeleniumHelper class
	 *
	 * @return The instance of the SeleniumHelper Class
	 */
	public static SeleniumHelper GetInstance() {
		if (m_instance == null) {
			m_instance = new SeleniumHelper();
		}
		return m_instance;
	}
}
