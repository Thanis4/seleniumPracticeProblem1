package pageobjects;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import junit.framework.Assert;
import selenium.SeleniumHelper;

public class MyStoreWomenPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreContactUsPage.class);
	private static MyStoreWomenPage m_instance;
	@FindBy(xpath = "//*[@id=\"center_column\"]/h1")
	WebElement contactUsHeader;
	
	@FindBy(xpath = "//li[contains(@class,'ajax_block_product')]")
	List<WebElement> dresses;

	private MyStoreWomenPage(WebDriver _driver) {
		m_pageTitle = "Women - My Store";
		PageFactory.initElements(_driver, this);
	}

	public void verifyDressesCountAndPrintIndividualPrice(String count) throws AssertionError {
		System.out.println("Total Dresses for Women: "+ Integer.toString(dresses.size()));
		System.out.println("Expected num: "+ count);
		for(WebElement d: dresses){
			WebElement dressPrice=d.findElement(By.xpath("div//div[@class='right-block']//span[@class='price product-price']"));
			WebElement dressName=d.findElement(By.xpath("div//div[@class='right-block']/h5/a"));

			log.info("Price: " +dressPrice.getText());
			log.info("Price: " +dressName.getText());
		}
		Assert.assertEquals(count, Integer.toString(dresses.size()), "Dress count is different");
	}
	
	public static MyStoreWomenPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreWomenPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
