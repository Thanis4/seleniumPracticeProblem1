package pageobjects;

//to generate random numbers.
import java.util.concurrent.ThreadLocalRandom;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreSignInPage extends MyStorePageObject {
	private static final Logger log = Logger.getLogger(MyStoreSignInPage.class);

	private static MyStoreSignInPage m_instance;
	@FindBy(id = "email_create")
	WebElement emailAddress;
	@FindBy(id = "SubmitCreate")
	WebElement createAnAccountButton;
	@FindBy(id = "email")
	WebElement registeredEmailAddress;
	@FindBy(id = "passwd")
	WebElement Password;
	@FindBy(id = "SubmitLogin")
	WebElement signInButton;
	private String lastUsedEmail;


	private MyStoreSignInPage(WebDriver _driver) {
		m_pageTitle = "Login - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreCreateAnAccountPage CreateAnAccount() {
		lastUsedEmail = "a" + getRandomInteger() + "@a.com";
		log.debug("Creating an Account");
		Selenium.Input(emailAddress, lastUsedEmail);
		Selenium.Click(createAnAccountButton);
		log.info("email used: " + lastUsedEmail);
		return MyStoreCreateAnAccountPage.GetInstance();
	}

	public MyStoreMyAccountPage SignIn() {
		String pswd = "aaa12";
		log.debug("Signing In");
		Selenium.Input(registeredEmailAddress, lastUsedEmail);
		Selenium.Input(Password, pswd);
		Selenium.Click(signInButton);
		log.info("email and Password used: " + lastUsedEmail + " | " + pswd);
		return MyStoreMyAccountPage.GetInstance();
	}


//Adding this new function for using scenario outline
		public MyStoreMyAccountPage SignInCredentials(String Registeredemail, String PasswordGiven) {
			String pswd = "aaa12";
			log.debug("Signing In");
			Selenium.Input(registeredEmailAddress, Registeredemail);
			Selenium.Input(Password, PasswordGiven);
			Selenium.Click(signInButton);
			log.info("email and Password used: " + lastUsedEmail + " | " + pswd);
			return MyStoreMyAccountPage.GetInstance();
		}

	public MyStoreSignInPage BadSignIn() {
		String pswd = "badpassword";
		log.debug("Signing In");
		Selenium.Input(registeredEmailAddress, "baduser");
		Selenium.Input(Password, pswd);
		Selenium.Click(signInButton);
		log.info("email and Password used: " + "baduser" + " | " + pswd);
		return GetInstance();
	}

	public static MyStoreSignInPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreSignInPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public int getRandomInteger() {
		// Generate random integers
		int rand_int = ThreadLocalRandom.current().nextInt();
		// Print random integers
		System.out.println("Random Integers: " + rand_int);
		return rand_int;
	}
}