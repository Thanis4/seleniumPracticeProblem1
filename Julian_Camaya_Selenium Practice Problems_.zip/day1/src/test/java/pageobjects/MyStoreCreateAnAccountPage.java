package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreCreateAnAccountPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreCreateAnAccountPage.class);
	private static MyStoreCreateAnAccountPage m_instance;
	@FindBy(id = "id_gender1")
	WebElement titleRadioButton_Mr;
	@FindBy(id = "id_gender2")
	WebElement titleRadioButton_Mrs;
	@FindBy(id = "customer_firstname")
	WebElement firstName;
	@FindBy(id = "customer_lastname")
	WebElement lastName;
	@FindBy(id = "passwd")
	WebElement password;
	@FindBy(id = "days")
	WebElement day;
	@FindBy(id = "months")
	WebElement month;
	@FindBy(id = "years")
	WebElement year;
	@FindBy(id = "company")
	WebElement company;
	@FindBy(id = "address1")
	WebElement addressLine1;
	@FindBy(id = "address2")
	WebElement addressLine2;
	@FindBy(id = "city")
	WebElement city;
	@FindBy(id = "id_state")
	WebElement state;
	@FindBy(id = "postcode")
	WebElement postalCode;
	@FindBy(id = "id_country")
	WebElement country;
	@FindBy(id = "phone")
	WebElement homePhone;
	@FindBy(id = "phone_mobile")
	WebElement mobilePhone;
	@FindBy(id = "alias")
	WebElement alias;
	@FindBy(id = "submitAccount")
	WebElement registerButton;

	private MyStoreCreateAnAccountPage(WebDriver _driver)
	{
		m_pageTitle = "Login - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreMyAccountPage EnterAccountDetails()
	{
		log.debug("entering account details");
		Selenium.Click(titleRadioButton_Mrs);
		Selenium.Input(firstName, "fname");
		Selenium.Input(lastName, "lname");
		Selenium.Input(password, "aaa12");
		Selenium.SelectFromDropDown(day, "1");
		Selenium.SelectFromDropDown(month, "1");
		Selenium.SelectFromDropDown(year, "2000");
		Selenium.Input(company, "My company");
		Selenium.Input(addressLine1, "My Address");
		Selenium.Input(city, "New York");
		Selenium.Input(state, "New York");
		Selenium.Input(postalCode, "10001");
		Selenium.Input(country, "United States");
		Selenium.Input(mobilePhone, "123456789");
		Selenium.Click(registerButton);
		return MyStoreMyAccountPage.GetInstance();
	}

	public static MyStoreCreateAnAccountPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreCreateAnAccountPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
