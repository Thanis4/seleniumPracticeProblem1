package com.seleniumttraining.day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import selenium.SeleniumHelper;

/**
 * Unit test for simple App.
 */
public class AppTest extends TestCase
{
	/**
	 * Create the test case
	 *
	 * @param testName name of the test case
	 */
	public AppTest(String testName)
	{
		super(testName);
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite()
	{
		return new TestSuite(AppTest.class);
	}

	/**
	 * Rigourous Test :-)
	 */
	public void testApp()
	{
		// System.setProperty("webdriver.chrome.driver",
		// "C:\\webdrivers\\chromedriver.exe");
		// WebDriver driver = new ChromeDriver();

		WebDriver driver = SeleniumHelper.GetInstance().GetDriver();

		driver.manage().window().maximize();
		driver.get("https://www.thebay.com/");

		String getTitle = SeleniumHelper.GetTitle();
		System.out.println(getTitle);

		String expectedTitle = "Hudson's Bay";

		if (driver.getTitle().matches(expectedTitle))
			// Pass
			System.out.println("Page title contains Yes");
		else
			// Fail
			System.out.println("No");

		By loc_email = By.id("sign-into-account-email-field");
		WebElement loginEmail = driver.findElement(loc_email);

		By loc_password = By.id("sign-into-account-password-field");
		WebElement loginPassword = driver.findElement(loc_password);

		By loc_order = By.id("order-status-order-number");
		WebElement loginOrder = driver.findElement(loc_order);

		By loc_postalcode = By.id("order-status-zip-code");
		WebElement loginPostalcode = driver.findElement(loc_postalcode);

		driver.quit();

	}
}
