package com.seleniumttraining.day1;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.MyStoreContactUsPage;
import pageobjects.MyStoreCreateAnAccountPage;
import pageobjects.MyStoreHomePage;
import pageobjects.MyStoreItemAddedToCartWindow;
import pageobjects.MyStoreItemDescriptionPage;
import pageobjects.MyStoreMyAccountPage;
import pageobjects.MyStoreSearchResultsPage;
import pageobjects.MyStoreShoppingCartPage;
import pageobjects.MyStoreSignInPage;
import selenium.SeleniumHelper;

public class Stepdefs
{
	MyStoreHomePage homePage = MyStoreHomePage.GetInstance();
	MyStoreSignInPage signInPage = MyStoreSignInPage.GetInstance();
	MyStoreCreateAnAccountPage createAccountPage = MyStoreCreateAnAccountPage.GetInstance();
	MyStoreMyAccountPage myAccoutnPage = MyStoreMyAccountPage.GetInstance();
	MyStoreContactUsPage contactUsPage = MyStoreContactUsPage.GetInstance();
	MyStoreSearchResultsPage searchResultsPage = MyStoreSearchResultsPage.GetInstance();
	MyStoreItemDescriptionPage itemDescriptionPage = MyStoreItemDescriptionPage.GetInstance();
	MyStoreItemAddedToCartWindow itemAddedToCartWindow = MyStoreItemAddedToCartWindow.GetInstance();
	MyStoreShoppingCartPage shoppingCartPage = MyStoreShoppingCartPage.GetInstance();

	@Given("^user is on homepage$")
	public void user_is_on_homepage() throws Exception
	{
		homePage.NavigateToThisPage();
	}

	@When("^user navigates to signinpage$")
	public void user_navigates_to_signinpage()
	{
		homePage.NavigateToSignInPage();
	}

	@When("user begins registration")
	public void user_begins_registration()
	{
		signInPage.CreateAnAccount();
	}

	@When("user enters default data")
	public void user_enters_default_data()
	{
		createAccountPage.EnterAccountDetails();
	}

	@When("user logs out")
	public void user_logs_out()
	{
		myAccoutnPage.SignOut();
	}

	@Then("verify signinpage title")
	public void verify_signinpage_title()
	{
		signInPage.VerifyTitle();
	}

	@When("user signs in")
	public void user_signs_in()
	{
		signInPage.SignIn();
	}

	@Then("verify myaccountpage title")
	public void verify_myaccountpage_title()
	{
		myAccoutnPage.VerifyTitle();
	}

	@When("user navigates to contactuspage")
	public void user_navigates_to_contactuspage()
	{
		myAccoutnPage.NavigateToContactUsPage();
	}

	@Then("verify contactuspage title")
	public void verify_contactuspage_title()
	{
		contactUsPage.VerifyTitle();
	}

	@When("user navigates to cart")
	public void user_navigates_to_cart()
	{
		// Write code here that turns the phrase above into concrete actions
		throw new cucumber.api.PendingException();
	}

	@When("user clicks on cart")
	public void user_clicks_on_cart()
	{
		// Write code here that turns the phrase above into concrete actions
		throw new cucumber.api.PendingException();
	}

	@Then("verify cart title")
	public void verify_cart_title()
	{
		// Write code here that turns the phrase above into concrete actions
		throw new cucumber.api.PendingException();
	}

	@When("user searches for {string}")
	public void user_searches_for(String string)
	{
		myAccoutnPage.SearchForItem(string);
		searchResultsPage.SelectItem(string);
	}

	@When("user adds item to cart")
	public void user_adds_item_to_cart()
	{
		itemDescriptionPage.AddItemToCart();
		SeleniumHelper.Seconds(2);
	}

	@When("user continues shopping")
	public void user_continues_shopping()
	{
		itemAddedToCartWindow.pressContinueShoppingButton();
		SeleniumHelper.Seconds(2);
	}

	@When("user clicks shopping cart")
	public void user_clicks_shopping_cart()
	{
		itemDescriptionPage.goToShoppingCart();
	}

	@Then("user verifies {string} is in cart")
	public void user_verifies_is_in_cart(String string)
	{
		shoppingCartPage.VerifyItemPresenceInCart(string);
	}

	@Then("user signs out")
	public void user_signs_out()
	{
		shoppingCartPage.SignOut();
	}
}
