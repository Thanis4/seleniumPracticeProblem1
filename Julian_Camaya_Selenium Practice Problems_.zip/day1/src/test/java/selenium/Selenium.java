package selenium;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class Selenium
{
	private static final Logger log = LogManager.getLogger(Selenium.class);

	public static void Input(WebElement _element, String _input)
	{
		log.debug("Entering text: " + _input + " to field: " + _element.toString());
		_element.click();
		_element.sendKeys(_input);
	}

	public static void SelectFromDropDown(WebElement _element, String _value)
	{
		log.debug("Selecting : " + _value + " to field: " + _element.toString());
		Select _select = new Select(_element);
		_select.selectByValue(_value);
	}

	public static void Click(WebElement _element)
	{
		log.debug("Clicking Element: " + _element.toString());
		SeleniumHelper.Seconds(2);
		_element.click();
// Seleniutilties.Seconds(2);
	}

	public static void ToggleCheckBox(By _locator)
	{
		WebElement _element = SeleniumHelper.FindElement(_locator);
		_element.click();
	}

	public static void CheckBox(By _locator, boolean _checked)
	{
		WebElement _element = SeleniumHelper.FindElement(_locator);
		if (_element.isSelected() && !_checked)
		{
// element is checked and should not be
			_element.click();
		} else if (!_element.isSelected() && _checked)
		{
// element is not checked and should be
			_element.click();
		}
	}

	public static void VerifyTextInElement(WebElement _element, String _expectedText)
	{
		String actualText;
		actualText = _element.getText();
		Assert.assertEquals(actualText, _expectedText);
		log.error(_expectedText + " was not equal to " + actualText);
	}

	public static void SelectRadioButttonsDynamically(List<WebElement> _elements, int[] selectedindex)
	{
		WebElement[] elements = _elements.toArray(new WebElement[0]);
		for (int index : selectedindex)
		{
			Click(elements[index]);
		}
	}

	public static void SystemAlert(boolean _accept)
	{
		Alert alert = SeleniumHelper.GetInstance().GetDriver().switchTo().alert();
		if (_accept)
		{
			alert.accept();
		} else
		{
			alert.dismiss();
		}
	}
}