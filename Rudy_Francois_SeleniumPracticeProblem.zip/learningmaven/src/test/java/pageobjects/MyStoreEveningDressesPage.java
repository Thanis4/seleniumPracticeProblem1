package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreEveningDressesPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreEveningDressesPage.class);
	private static MyStoreEveningDressesPage m_instance;
	private String m_url;
	@FindBy(linkText = "Dresses")
	WebElement dressesMenu;
	@FindBy(xpath = "//*[@id=\"categories_block_left\"]/div/ul/li[2]/a")
	WebElement eveningDressesMenu;

	private MyStoreEveningDressesPage(WebDriver _driver) {
		m_pageTitle = "Evening Dresses - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreEveningDressesPage NavigateToThisPage() {
		SeleniumHelper.Get(m_url);
		return GetInstance();
	}

	public static MyStoreEveningDressesPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreEveningDressesPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
