package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreHomePage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreHomePage.class);
	private static MyStoreHomePage m_instance;
	private String m_url;
	@FindBy(linkText = "Sign in")
	WebElement signInButton;
	@FindBy(xpath = "//*[@id=\"contact-link\"]/a")
	WebElement contactUsButton;
	@FindBy(xpath = "//*[@id=\"block_top_menu\"]/ul/li[2]/a")
	WebElement dressesMenu;

	private MyStoreHomePage(WebDriver _driver) {
		log.debug("creating Home Page PageObject");
		m_url = "http://automationpractice.com/index.php";
		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreHomePage NavigateToThisPage() {
		SeleniumHelper.Get(m_url);
		return GetInstance();
	}

	public MyStoreSignInPage NavigateToSignInPage() {
		log.debug("navigating to signin page");
		Selenium.Click(signInButton);
		return MyStoreSignInPage.GetInstance();
	}

	public MyStoreContactUsPage NavigateToContactUsPage() {
		log.debug("navigating to Contact Us page");
		Selenium.Click(contactUsButton);
		return MyStoreContactUsPage.GetInstance();
	}
	
	public MyStoreDressesPage NavigatetoDressesPage() {
		log.debug("navigating to Dresses page");
		Selenium.Click(dressesMenu);
		return MyStoreDressesPage.GetInstance();
	}

	public static MyStoreHomePage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreHomePage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public void TriggerAssert() throws AssertionError {
		throw new AssertionError("This should FAIL");
	}
}