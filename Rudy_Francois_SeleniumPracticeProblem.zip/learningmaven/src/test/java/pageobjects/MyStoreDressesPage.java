package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreDressesPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreDressesPage.class);
	private static MyStoreDressesPage m_instance;
	private String m_url;
	@FindBy(linkText = "Dresses")
	WebElement dressesMenu;
	@FindBy(xpath = "//*[@id=\"categories_block_left\"]/div/ul/li[2]/a")
	WebElement eveningDressesMenu;

	private MyStoreDressesPage(WebDriver _driver) {
		m_pageTitle = "Dresses - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreDressesPage NavigateToThisPage() {
		SeleniumHelper.Get(m_url);
		return GetInstance();
	}
	
	public MyStoreEveningDressesPage NavigateToEveningDressesPage() {
		log.debug("navigating to Evening Dresses Page");
		Selenium.Click(eveningDressesMenu);
		return MyStoreEveningDressesPage.GetInstance();
	}

	public static MyStoreDressesPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreDressesPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
