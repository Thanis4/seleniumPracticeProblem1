package com.mywork.learningMaven;

/**
 * Hello world!
 *
 */

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import java.util.List;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions; 


public class App 
{
	private static WebDriver driver;
	
	public static void main( String[] args )
    {
        System.out.println( "Hello World!" );

        System.setProperty("webdriver.chrome.driver", "\\Selenium\\chromedriver_win32\\chromedriver.exe");
        
  	  // Initialize browser
        	 driver=new ChromeDriver();
        	 
        	// Open Google
 //       	driver.get("http://www.google.com");
        	 
           	driver.get("http://automationpractice.com/index.php");
                   	        	
        
           	boolean _pageTitle = VerifyPageTitle("My Store");
           	
           	System.out.print(_pageTitle);        	

           	
          //*[@id="header"]/div[3]/div/div/div[3]/div/a
           	
        	// Close browser
        	driver.close();
        	
    
    }
	public static boolean VerifyPageTitle(String _expTitle)
	{
		String pageTitle;
		pageTitle = driver.getTitle();
		if (pageTitle.contains(_expTitle))
		{
			return true;
		} else
		{
			return false;
		}
	}
	   	

}

