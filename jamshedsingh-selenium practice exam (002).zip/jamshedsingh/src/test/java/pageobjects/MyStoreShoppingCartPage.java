package pageobjects;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.SeleniumHelper;

public class MyStoreShoppingCartPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreShoppingCartPage.class);
	private static MyStoreShoppingCartPage m_instance;

	@FindBy(xpath = "//table[@id='cart_summary']/tbody//tr")
	List<WebElement> cart_table_rows;
	
	@FindBy(xpath = "//a[@title='Proceed to checkout'][contains(@class,'checkout')]")
	WebElement proceed_to_checkout;
	
	@FindBy(xpath = "//h1")
	WebElement heading1;
	
	@FindBy(xpath = "//h3")
	WebElement heading3;
	
	@FindBy(id = "cgv")
	WebElement termofServiceChkBox;
	
	@FindBy(xpath = "//a[@title='Pay by check.']")
	WebElement payByCheque;
	
	@FindBy(xpath = "//button[@type='submit']")
	WebElement submitBtn;
	
	@FindBy(xpath = "//button[@type='submit'][contains(@class,'button-medium')]")
	WebElement proceed_to_checkout_submit;
	
	@FindBy(xpath = "//p[@class='alert alert-success']")
	WebElement orderSuccessMessage;
	
	
	private MyStoreShoppingCartPage(WebDriver _driver) {
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreShoppingCartPage VerifyItemPresenceInCart(String _itemName) {
		log.debug("Verifying item presence in the cart");
		if (SeleniumHelper.VerifyTextPresentOnPage(_itemName)) {
			log.info("The item " + _itemName + " was successfully found in cart");
		} else {
			log.error("The item " + _itemName + " was NOT found in cart");
		}
		return MyStoreShoppingCartPage.GetInstance();
	}

	public static MyStoreShoppingCartPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreShoppingCartPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public void VerifyItemsInCartAreInStock() {
		for (WebElement row : cart_table_rows) {
			String itemAvailability = row.findElement(By.xpath("td[@class='cart_avail']/span")).getText();
			String itemName = row.findElement(By.xpath("td/p[@class='product-name']")).getText();
			if (itemAvailability.equalsIgnoreCase("In stock"))
				log.info(itemName + " is in stock");
			else
				log.error(itemName + " is out of stock");

		}
	}
	
	public void clickProceedToCheckoutBtn(){
		proceed_to_checkout.click();
	}
	
	public void clickProceedToCheckoutSubmitBtn(){
		proceed_to_checkout_submit.click();
	}

	
	public void verifyAddressSection() {
		log.debug("Verifying Address section on shopping cart page");
		if (heading1.getText().equalsIgnoreCase("ADDRESSES")) {
			log.info("User is successfully navigated to Address section of shopping cart page");
		} else {
			log.error("User is not navigated to Address section of shopping cart page");
		}

	}
	
	public void verifyShippingSection() {
		log.debug("Verifying Address section on shopping cart page");
		if (heading1.getText().equalsIgnoreCase("ADDRESSES")) {
			log.info("User is successfully navigated to shipping section of shopping cart page");
		} else {
			log.error("User is not navigated to shipping section of shopping cart page");
		}

	}

	public void clickTermOfServiceBtn() {
		termofServiceChkBox.click();
	}

	public void clickPayByCheckOption() {
		payByCheque.click();
		
	}

	public void verifyCheckPaymentTxt() {
		log.debug("Verifying CheckPayment section on Order summery Page");
		if (heading3.getText().equalsIgnoreCase("CHECK PAYMENT")) {
			log.info("Check Payment is displayed");
		} else {
			log.error("Check Payment is not displayed");
		}

	}
	
	public void clickConfirmMyOrder() {
		submitBtn.click();
	}

	public void verifyOrderConfirmationMessage() {
		log.debug("Verifying CheckPayment section on Order summery Page");
		if (orderSuccessMessage.getText().equalsIgnoreCase("Your order on My Store is complete.")) {
			log.info("Order Success Message is displayed");
		} else {
			log.error("Order Success message is not displayed");
		}

	}

	
}
