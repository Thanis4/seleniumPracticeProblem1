package pageobjects;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.SeleniumHelper;

public class MyStoreCheckoutAddressPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreShoppingCartPage.class);
	private static MyStoreCheckoutAddressPage m_instance;

	@FindBy(xpath = "//table[@id='cart_summary']/tbody//tr")
	List<WebElement> cart_table_rows;
	
	@FindBy(xpath = "//button[@name='processAddress']")
	WebElement proceed_to_checkout;
	
	@FindBy(xpath = "//h1")
	WebElement heading1;
	
	
	private MyStoreCheckoutAddressPage(WebDriver _driver) {
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}

	public static MyStoreCheckoutAddressPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreCheckoutAddressPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public void clickProceedToCheckoutBtn(){
		proceed_to_checkout.click();
	}

	
	public void verifyAddressSection() {
		log.debug("Verifying Address section on shopping cart page");
		if (heading1.getText().equalsIgnoreCase("ADDRESSES")) {
			log.info("User is successfully navigated to Address section of shopping cart page");
		} else {
			log.error("User is not navigated to Address section of shopping cart page");
		}

	}
	
	
}
