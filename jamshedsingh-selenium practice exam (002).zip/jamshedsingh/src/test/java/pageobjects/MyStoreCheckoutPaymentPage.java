package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.SeleniumHelper;

public class MyStoreCheckoutPaymentPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreShoppingCartPage.class);
	private static MyStoreCheckoutPaymentPage m_instance;

	@FindBy(xpath = "//a[@title='Proceed to checkout'][contains(@class,'checkout')]")
	WebElement proceed_to_checkout;
	
	@FindBy(xpath = "//h3")
	WebElement heading3;
	
	@FindBy(xpath = "//a[@title='Pay by check.']")
	WebElement payByCheque;
	
	@FindBy(xpath = "//span[contains(text(),'I confirm my order')]/parent::button")
	WebElement proceedToCheckoutBtn;
	
	@FindBy(xpath = "//button[@type='submit'][contains(@class,'button-medium')]")
	WebElement proceed_to_checkout_submit;
	
	@FindBy(xpath = "//p[@class='alert alert-success']")
	WebElement orderSuccessMessage;
	
	
	private MyStoreCheckoutPaymentPage(WebDriver _driver) {
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreShoppingCartPage VerifyItemPresenceInCart(String _itemName) {
		log.debug("Verifying item presence in the cart");
		if (SeleniumHelper.VerifyTextPresentOnPage(_itemName)) {
			log.info("The item " + _itemName + " was successfully found in cart");
		} else {
			log.error("The item " + _itemName + " was NOT found in cart");
		}
		return MyStoreShoppingCartPage.GetInstance();
	}

	public static MyStoreCheckoutPaymentPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreCheckoutPaymentPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public void verifyCheckPaymentTxt() {
		log.debug("Verifying CheckPayment section on Order summery Page");
		if (heading3.getText().equalsIgnoreCase("CHECK PAYMENT")) {
			log.info("Check Payment is displayed");
		} else {
			log.error("Check Payment is not displayed");
		}

	}
	
	public void clickPayByCheckOption() {
		payByCheque.click();
		
	}
	
	public void clickConfirmMyOrder() {
		proceedToCheckoutBtn.click();
	}

	public void verifyOrderConfirmationMessage() {
		log.debug("Verifying CheckPayment section on Order summery Page");
		if (orderSuccessMessage.getText().equalsIgnoreCase("Your order on My Store is complete.")) {
			log.info("Order Success Message is displayed");
		} else {
			log.error("Order Success message is not displayed");
		}

	}

	
}
